from setuptools import setup
setup(name="packageaditya",
      version="0.1",
      description="Aditya Package",
      author="Aditya",
      packages=['packageaditya'],
      install_requires=['datetime', 'random2'])